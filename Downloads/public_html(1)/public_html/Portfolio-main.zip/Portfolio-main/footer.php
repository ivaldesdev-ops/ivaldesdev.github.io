<footer>
  <p>&copy; <?php echo date('Y'); ?> Your Name. All rights reserved.</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>

