<?php
/* Template Name: Present Projects */
get_header();
?>
<h2>Present Projects</h2>
<p>Here are the projects I am currently working on.</p>
<?php get_footer(); ?>
