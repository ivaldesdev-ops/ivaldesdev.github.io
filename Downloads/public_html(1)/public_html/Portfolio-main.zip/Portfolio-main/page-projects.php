<?php
/* Template Name: Projects Page */
get_header();
?>
<h2>Projects</h2>
<p>Explore my past and present development projects.</p>
<?php get_footer(); ?>


/* ====== page-projects-past.php ====== */
<?php
/* Template Name: Past Projects */
get_header();
?>
<h2>Past Projects</h2>
<p>Here are some of the projects I've completed in the past.</p>
<?php get_footer(); ?>
