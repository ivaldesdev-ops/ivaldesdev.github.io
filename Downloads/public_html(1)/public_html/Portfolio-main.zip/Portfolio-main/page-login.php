<?php
/* Template Name: Login Page */
get_header();
?>
<h2>Login</h2>
<form method="post">
  <label>Email:<br><input type="email" name="email" required></label><br>
  <label>Password:<br><input type="password" name="password" required></label><br>
  <button type="submit">Login</button>
</form>
<?php get_footer(); ?>
