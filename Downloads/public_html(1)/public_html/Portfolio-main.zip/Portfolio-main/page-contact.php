<?php
/* Template Name: Contact Page */
get_header();
?>
<h2>Contact Me</h2>
<form method="post">
  <label>Name:<br><input type="text" name="name" required></label><br>
  <label>Email:<br><input type="email" name="email" required></label><br>
  <label>Message:<br><textarea name="message" required></textarea></label><br>
  <button type="submit">Send</button>
</form>
<?php get_footer(); ?>
