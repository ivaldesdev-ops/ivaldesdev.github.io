export interface Habit {
  id: number;
  name: string;
  completed: boolean;
  completedDates: Date[];
}